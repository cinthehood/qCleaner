﻿using System;
using System.IO;

class Program
{
    static void Main()
    {
        // Sabit temp klasör yolları
        string[] folderPaths = new string[]
        {
            @"C:\Windows\Temp",
            @"C:\Users\frcin\AppData\Local\Temp"
        };

        long totalFreedSpace = 0;
        int deletedFilesCount = 0;

        foreach (var folderPath in folderPaths)
        {
            // Klasör yolunun geçerli olup olmadığını kontrol et
            if (Directory.Exists(folderPath))
            {
                Console.WriteLine($"{folderPath} klasöründe bulunan dosyalar temizleniyor...");

                DirectoryInfo directoryInfo = new DirectoryInfo(folderPath);
                FileInfo[] files = directoryInfo.GetFiles();

                foreach (var file in files)
                {
                    try
                    {
                        long fileSize = file.Length;
                        totalFreedSpace += fileSize;

                        file.Delete();  // Dosyayı sil
                        deletedFilesCount++;

                        Console.WriteLine($"Silindi: {file.FullName}, Boyut: {FormatBytes(fileSize)}");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Hata oluştu: {ex.Message} (Dosya: {file.FullName})");
                    }
                }

                Console.WriteLine($"{folderPath} klasöründe işlem tamamlandı.");
            }
            else
            {
                Console.WriteLine($"{folderPath} yolu bulunamadı veya geçerli değil.");
            }
        }

        Console.WriteLine("\nTemizlik tamamlandı.");
        Console.WriteLine($"Toplam {deletedFilesCount} dosya silindi.");
        Console.WriteLine($"Açılan alan: {FormatBytes(totalFreedSpace)}");

        Console.WriteLine("\nProgramdan çıkmak için bir tuşa basın...");
        Console.ReadKey();
    }

    // Byte'ları okunabilir formata dönüştürme (örneğin: 1 KB, 10 MB, 1 GB)
    static string FormatBytes(long bytes)
    {
        string[] suffixes = { "B", "KB", "MB", "GB", "TB" };
        double size = bytes;
        int order = 0;

        while (size >= 1024 && order < suffixes.Length - 1)
        {
            order++;
            size /= 1024;
        }

        return string.Format("{0:0.##} {1}", size, suffixes[order]);
    }
}
